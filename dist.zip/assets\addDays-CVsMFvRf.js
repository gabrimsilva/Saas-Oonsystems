import{t,c as a}from"./pt-BR-y6bM7RF1.js";function s(s,e,n){const o=t(s,n?.in);return isNaN(e)?a(s,NaN):e?(o.setDate(o.getDate()+e),o):o}export{s as a};
